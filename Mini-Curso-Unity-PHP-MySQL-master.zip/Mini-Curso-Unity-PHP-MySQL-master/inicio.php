<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Inicio</title>
</head>

<body>

<?php
	echo"Hello World";
	
	?>
	
	








</body>
</html>