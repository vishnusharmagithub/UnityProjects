<?php
echo"...Testando se o php está funcionando...";
echo"...agora com NP++ como file transfer";
echo phpinfo();
?>

