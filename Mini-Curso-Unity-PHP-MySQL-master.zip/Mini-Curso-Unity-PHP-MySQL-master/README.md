# Mini-Curso-Unity-PHP-MySQL
A simple example using a Unity script to access PHP pages on an Apache Server to login to a MySQL Database

In the main directory, simple php scripts to access the MySQl database "teste", where we insert/delete/update login and password of a user.
In the directory "login", there is a Unity project called "Login", created using the 2D mode.

