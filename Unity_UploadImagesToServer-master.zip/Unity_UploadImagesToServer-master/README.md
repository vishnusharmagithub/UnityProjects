# Upload images to a Server (PHP)

Click on the image to watch the tutorial:

[![Tutorial](https://img.youtube.com/vi/Bp4h4pmcw3c/0.jpg)](https://www.youtube.com/watch?v=Bp4h4pmcw3c)
